Copyright (c) 2024, Thai Nguyen <privat_thai_nguyen@hotmail.com> 

Tab Manager Browser Plugin - v1.0.0, https://github.com/Njugen/Tab-Manager-Browser-Plugin

This software is free for personal and professional use. The software itself and code deriving from it may not be monetized, nor used as part of commercial products/services/brands. The software and its source code (and/or code deriving from it) may not be distributed through other channels than those maintained by the author.

The software is provided as is, without warranty of any kind. The user of this software is entirely responsible for any kind of damages, legal issues and/or liabilities that might arise from use of this software.

